import type { Facility } from '../types/facility';

/**
 * Master dataset — Phase 2. 20 flagship HEP facilities across all major
 * categories. Uncertain facts are marked // [verify].
 *
 * Phase 3: side panel looks up any Facility by selectedFacilityId from here.
 * Phase 4: derive filter chip values from the topics arrays below.
 */
export const facilities: readonly Facility[] = [

  // ─── Hadron Colliders ─────────────────────────────────────────────────────

  {
    id: 'cern',
    name: 'CERN',
    country: 'Switzerland / France',
    lat: 46.2331,
    lng: 6.0558,
    founded: 1954,
    status: 'active',
    overview: "The European Organization for Nuclear Research (CERN), founded in 1954, operates the world's largest and most powerful particle accelerator complex on the Franco-Swiss border near Geneva. Its 27-kilometre Large Hadron Collider (LHC) accelerates protons to 99.9999991% the speed of light and collides them at four interaction points where ATLAS, CMS, ALICE, and LHCb record the debris. CERN is also the birthplace of the World Wide Web (1989) and a model of global scientific collaboration, involving over 17,000 scientists from more than 100 countries.",
    history: [
      { year: 1954, event: "CERN founded by 12 European member states, establishing Geneva as the world's leading centre for particle physics." },
      { year: 1983, event: "UA1 and UA2 experiments at the SPS collider discover the W\u00b1 and Z\u2070 bosons, confirming electroweak unification. Carlo Rubbia and Simon van der Meer awarded the Nobel Prize in 1984." },
      { year: 1989, event: "Large Electron-Positron Collider (LEP) begins operations, enabling precision electroweak measurements and establishing that exactly four light neutrino generations exist." },
      { year: 2008, event: "Large Hadron Collider (LHC) begins first beam operations at 7 TeV centre-of-mass energy, becoming the world's highest-energy collider." },
      { year: 2012, event: "ATLAS and CMS jointly announce the observation of a Higgs boson at ~125 GeV, completing the Standard Model. Peter Higgs and Francois Englert awarded the Nobel Prize in 2013." },
    ],
    experiments: [
      { id: 'cern-atlas', name: 'ATLAS', description: "General-purpose detector that co-discovered the Higgs boson; searches for supersymmetry, dark matter candidates, and extra dimensions at the LHC.", topics: ['higgs', 'dark-matter', 'qcd', 'electroweak'], startYear: 2008 },
      { id: 'cern-cms', name: 'CMS', description: "General-purpose detector with a 4-tesla superconducting solenoid; co-discovered the Higgs boson and leads precision Higgs coupling measurements.", topics: ['higgs', 'dark-matter', 'qcd', 'electroweak'], startYear: 2008 },
      { id: 'cern-alice', name: 'ALICE', description: "Dedicated heavy-ion detector studying quark-gluon plasma created in Pb-Pb collisions at the LHC, recreating conditions microseconds after the Big Bang.", topics: ['heavy-ions', 'qcd'], startYear: 2008 },
      { id: 'cern-lhcb', name: 'LHCb', description: "Specialised b-physics detector measuring CP violation and rare B-meson decays, probing the matter-antimatter asymmetry of the universe.", topics: ['b-physics', 'cp-violation'], startYear: 2008 },
    ],
    keyResults: [
      { year: 1983, discovery: "W and Z Boson Discovery", description: "UA1 and UA2 at the CERN SPS provided the first direct observation of the massive W\u00b1 and Z\u2070 bosons mediating the weak nuclear force, confirming the Glashow-Salam-Weinberg electroweak theory. Nobel Prize 1984." },
      { year: 2012, discovery: "Higgs Boson Discovery", description: "ATLAS and CMS observed a scalar boson at ~125 GeV consistent with the long-sought Higgs boson, the last missing piece of the Standard Model and the origin of particle mass. Nobel Prize 2013." },
    ],
    importantPeople: [
      { name: "Carlo Rubbia", contribution: "Led the UA1 experiment and the discovery of the W and Z bosons; Nobel Prize in Physics 1984." },
      { name: "Tim Berners-Lee", contribution: "Invented the World Wide Web at CERN in 1989 to enable global information sharing among particle physicists." },
      { name: "Fabiola Gianotti", contribution: "ATLAS spokesperson during the 2012 Higgs discovery announcement; first female Director-General of CERN (2016-present)." },
    ],
    readMore: [
      { label: "Official Site", url: "https://home.cern" },
      { label: "Nobel Prize 1984 (W/Z Bosons)", url: "https://www.nobelprize.org/prizes/physics/1984/summary/" },
      { label: "Nobel Prize 2013 (Higgs Boson)", url: "https://www.nobelprize.org/prizes/physics/2013/summary/" },
    ],
  },

  {
    id: 'fermilab',
    name: 'Fermilab',
    country: 'United States',
    lat: 41.8316,
    lng: -88.2456,
    founded: 1967,
    status: 'active',
    overview: "Fermi National Accelerator Laboratory in Batavia, Illinois was home to the Tevatron (1983-2011), the world's highest-energy proton-antiproton collider before the LHC. Its CDF and DZero experiments discovered the top quark in 1995. Today Fermilab leads the US neutrino programme with the NOvA long-baseline experiment and the Short-Baseline Neutrino (SBN) programme, and is building the Deep Underground Neutrino Experiment (DUNE) — a 1,300-km baseline beam to SURF in South Dakota.",
    history: [
      { year: 1967, event: "National Accelerator Laboratory founded under director Robert Wilson; construction of the main proton synchrotron begins." },
      { year: 1977, event: "Leon Lederman's team discovers the Upsilon (Y) meson at the 400-GeV main ring, providing the first evidence for the bottom quark." },
      { year: 1983, event: "Tevatron superconducting synchrotron begins operations at 900 GeV, the world's first superconducting collider." },
      { year: 1995, event: "CDF and DZero simultaneously announce the discovery of the top quark in proton-antiproton collisions at the Tevatron, completing the three-generation quark picture." },
      { year: 2011, event: "Tevatron retired after 28 years; Fermilab pivots to become the US hub for neutrino physics with the PIP-II accelerator upgrade and DUNE programme." },
    ],
    experiments: [
      { id: 'fermilab-cdf', name: 'CDF', description: "Collider Detector at Fermilab; co-discovered the top quark at the Tevatron proton-antiproton collider in 1995 and made precision electroweak measurements.", topics: ['qcd', 'electroweak'], startYear: 1985, endYear: 2011 },
      { id: 'fermilab-d0', name: 'DZero', description: "Second Tevatron multipurpose detector; independently co-discovered the top quark and set world-leading constraints on the W-boson mass.", topics: ['qcd', 'electroweak'], startYear: 1992, endYear: 2011 },
      { id: 'fermilab-nova', name: 'NOvA', description: "NuMI Off-Axis neutrino Appearance experiment measuring oscillation parameters and the CP-violating phase delta on an 810-km baseline from Fermilab to Minnesota.", topics: ['neutrinos'], startYear: 2014 },
      { id: 'fermilab-mu2e', name: 'Mu2e', description: "Searches for charged-lepton-flavour-violating muon-to-electron conversion in the field of a nucleus — a signal of physics beyond the Standard Model with sensitivity four orders of magnitude beyond previous limits.", topics: ['electroweak'] },
    ],
    keyResults: [
      { year: 1977, discovery: "Bottom Quark Discovery", description: "The Upsilon meson resonance observed at Fermilab's 400-GeV proton synchrotron provided the first experimental evidence for the bottom (b) quark, completing the second quark generation." },
      { year: 1995, discovery: "Top Quark Discovery", description: "CDF and DZero independently observed the top quark in proton-antiproton collisions at the Tevatron, with a mass of ~175 GeV — far heavier than any other known quark — completing the Standard Model fermion sector." },
    ],
    importantPeople: [
      { name: "Robert Wilson", contribution: "Founding director of Fermilab (1967-1978); designed the laboratory and its architecture, championing the cultural value of basic science before Congress." },
      { name: "Leon Lederman", contribution: "Fermilab director (1979-1989); led the team that discovered the bottom quark in 1977. Nobel Prize in Physics 1988 (for muon-neutrino discovery at BNL)." },
      { name: "Helen Edwards", contribution: "Chief engineer of the Tevatron; pioneered the superconducting magnet technology that made the world's first superconducting synchrotron collider possible." },
    ],
    readMore: [
      { label: "Official Site", url: "https://www.fnal.gov" },
      { label: "Tevatron Legacy", url: "https://www.fnal.gov/pub/tevatron/" },
    ],
  },

  {
    id: 'brookhaven',
    name: 'Brookhaven / RHIC',
    country: 'United States',
    lat: 40.8676,
    lng: -72.8776,
    founded: 1947,
    status: 'active',
    overview: "Brookhaven National Laboratory on Long Island, New York, has been a world leader in nuclear and particle physics since 1947. Its Relativistic Heavy Ion Collider (RHIC), operational since 2000, collides gold nuclei at near-light speed to produce quark-gluon plasma — the state of matter that existed microseconds after the Big Bang. In 2005 the four RHIC experiments announced that this plasma behaves as a near-perfect liquid with extraordinarily low viscosity, transforming our understanding of nuclear matter.",
    history: [
      { year: 1947, event: "Brookhaven National Laboratory established by the US Atomic Energy Commission, operated by a consortium of northeastern universities." },
      { year: 1974, event: "Samuel Ting's team at BNL co-discovers the J/psi meson simultaneously with Burton Richter's group at SLAC — the November Revolution that revealed the charm quark. Nobel Prize 1976." },
      { year: 1964, event: "The Omega-minus baryon is discovered at BNL's Alternating Gradient Synchrotron (AGS), confirming Gell-Mann's quark model and the SU(3) symmetry of hadrons." },
      { year: 2000, event: "Relativistic Heavy Ion Collider (RHIC) begins operations, enabling Au+Au collisions at centre-of-mass energies up to 200 GeV per nucleon pair." },
      { year: 2005, event: "STAR, PHENIX, BRAHMS, and PHOBOS collaborations jointly announce that RHIC collisions produce a strongly-coupled quark-gluon plasma that flows like a near-perfect liquid." },
    ],
    experiments: [
      { id: 'bnl-star', name: 'STAR', description: "Solenoidal Tracker at RHIC; studies the quark-gluon plasma using large-acceptance charged-particle tracking and calorimetry across a wide range of collision energies.", topics: ['heavy-ions', 'qcd'], startYear: 2000 },
      { id: 'bnl-phenix', name: 'PHENIX', description: "Pioneering RHIC detector measuring photons, leptons, and hadrons in heavy-ion collisions; key to establishing the perfect-liquid interpretation of the QGP.", topics: ['heavy-ions', 'qcd'], startYear: 2000, endYear: 2016 },
    ],
    keyResults: [
      { year: 1974, discovery: "J/psi Meson Discovery", description: "Simultaneous discovery at BNL and SLAC of the J/psi meson, revealing the charm quark and inaugurating the November Revolution in particle physics. Nobel Prize in Physics 1976." },
      { year: 2005, discovery: "Strongly-Coupled Quark-Gluon Plasma", description: "RHIC experiments established that the quark-gluon plasma formed in gold-gold collisions is a near-perfect liquid with a shear viscosity-to-entropy ratio close to the quantum mechanical minimum." },
    ],
    importantPeople: [
      { name: "Samuel Ting", contribution: "Led the E598 experiment at BNL that co-discovered the J/psi meson; Nobel Prize in Physics 1976." },
      { name: "Nicholas Samios", contribution: "BNL director (1982-1996); earlier co-discovered the Omega-minus baryon in 1964, confirming the quark model and SU(3) flavour symmetry." },
    ],
    readMore: [
      { label: "Official Site", url: "https://www.bnl.gov" },
      { label: "RHIC", url: "https://www.bnl.gov/rhic/" },
      { label: "Nobel Prize 1976 (J/psi)", url: "https://www.nobelprize.org/prizes/physics/1976/summary/" },
    ],
  },

  // ─── Electron-Positron Colliders ──────────────────────────────────────────

  {
    id: 'kek',
    name: 'KEK / Belle II',
    country: 'Japan',
    lat: 36.1512,
    lng: 140.0712,
    founded: 1971,
    status: 'active',
    overview: "The High Energy Accelerator Research Organization (KEK) in Tsukuba, Japan operates SuperKEKB — an asymmetric-energy electron-positron collider designed to produce B mesons near their pair-production threshold. The Belle II detector, collecting data since 2019, aims to accumulate 50 times the dataset of its predecessor Belle to search for CP violation, rare decays, and dark-sector particles with unprecedented precision.",
    history: [
      { year: 1971, event: "KEK founded as Japan's national high-energy physics laboratory in Tsukuba Science City." },
      { year: 1998, event: "Belle experiment begins data-taking at the asymmetric KEKB collider, designed to measure CP violation in B-meson decays." },
      { year: 2001, event: "Belle and BaBar (SLAC) independently report large CP violation in B0 meson decays, confirming the Kobayashi-Maskawa mechanism. Nobel Prize 2008." },
      { year: 2010, event: "KEKB retires after delivering over 1000 fb-1. Construction of SuperKEKB, targeting 40x higher luminosity, begins." },
      { year: 2019, event: "Belle II detector begins physics runs at SuperKEKB, targeting the world record luminosity of 6 x 10^35 cm-2 s-1." },
    ],
    experiments: [
      { id: 'kek-belle2', name: 'Belle II', description: "Precision B-factory detector measuring CP violation and rare B- and D-meson decays, and searching for dark photons, axion-like particles, and other light dark-sector mediators.", topics: ['b-physics', 'cp-violation', 'dark-matter'], startYear: 2019 },
      { id: 'kek-belle', name: 'Belle', description: "Predecessor B-factory experiment whose measurement of CP violation in B0 decays confirmed the Kobayashi-Maskawa quark-mixing mechanism.", topics: ['b-physics', 'cp-violation'], startYear: 1998, endYear: 2010 },
    ],
    keyResults: [
      { year: 2001, discovery: "CP Violation in B Mesons Confirmed", description: "Belle (and BaBar at SLAC) measured large CP asymmetry in B0 decays, directly confirming the Kobayashi-Maskawa mechanism and explaining why our universe has more matter than antimatter. Nobel Prize 2008." },
    ],
    importantPeople: [
      { name: "Makoto Kobayashi", contribution: "Co-proposed the CKM quark mixing matrix in 1973, predicting a third generation of quarks from CP-violation arguments; Nobel Prize in Physics 2008." },
      { name: "Toshihide Maskawa", contribution: "Co-proposed the CKM matrix and provided the theoretical framework confirmed by Belle and BaBar; Nobel Prize in Physics 2008." },
    ],
    readMore: [
      { label: "KEK Official Site", url: "https://www.kek.jp" },
      { label: "Belle II Experiment", url: "https://www.belle2.org" },
      { label: "Nobel Prize 2008 (CKM)", url: "https://www.nobelprize.org/prizes/physics/2008/summary/" },
    ],
  },

  // ─── Underground Neutrino / Dark Matter Labs ──────────────────────────────

  {
    id: 'gran-sasso',
    name: 'Gran Sasso (LNGS)',
    country: 'Italy',
    lat: 42.4536,
    lng: 13.576,
    founded: 1987,
    status: 'active',
    overview: "The Laboratori Nazionali del Gran Sasso (LNGS) beneath the Apennine Mountains in central Italy is the world's largest underground research laboratory, with three experimental halls at 1,400 m rock overburden. Its extreme shielding from cosmic-ray muons makes it ideal for rare-event searches including neutrinoless double-beta decay, WIMP dark matter detection, solar neutrino spectroscopy, and neutrino oscillation studies using beams sent from CERN 730 km away.",
    history: [
      { year: 1982, event: "Pioneering experiments begin during construction of the Gran Sasso highway tunnel, exploiting the natural rock shielding for low-background physics." },
      { year: 1987, event: "LNGS formally established by INFN and opened to the international physics community as the world's largest underground laboratory." },
      { year: 2007, event: "OPERA experiment begins detecting tau-neutrino candidates from the CNGS muon-neutrino beam sent from CERN, probing nu_mu to nu_tau oscillation." },
      { year: 2014, event: "BOREXINO makes the first direct real-time measurement of low-energy pp solar neutrinos, providing a direct window into the dominant fusion chain of the Sun." },
      { year: 2020, event: "XENONnT, a 5.9-tonne liquid-xenon TPC, begins operations, setting world-leading upper limits on WIMP-nucleon cross sections." },
    ],
    experiments: [
      { id: 'lngs-borexino', name: 'BOREXINO', description: "Ultra-pure liquid-scintillator detector that made the first real-time measurement of solar pp, pep, and CNO neutrinos, providing a direct window into solar fusion reactions.", topics: ['neutrinos'], startYear: 2007 },
      { id: 'lngs-xenon', name: 'XENONnT', description: "5.9-tonne dual-phase liquid-xenon TPC at Gran Sasso searching for WIMP dark matter and neutrinoless double-beta decay with world-leading sensitivity.", topics: ['dark-matter', 'neutrinos'], startYear: 2020 },
      { id: 'lngs-opera', name: 'OPERA', description: "Observed the first direct tau-neutrino appearance events from a pure muon-neutrino beam (CNGS), providing the clearest proof of nu_mu to nu_tau oscillation.", topics: ['neutrinos'], startYear: 2006, endYear: 2012 },
    ],
    keyResults: [
      { year: 2010, discovery: "First Direct Tau Neutrino Appearance", description: "OPERA detected the first tau-neutrino candidate events from a pure muon-neutrino beam fired 730 km from CERN, providing the first direct observation of nu_mu to nu_tau oscillation." },
      { year: 2014, discovery: "First Direct Detection of Solar pp Neutrinos", description: "BOREXINO made the world's first direct, real-time measurement of neutrinos from the pp fusion reaction, the dominant energy source of the Sun, confirming Standard Solar Model predictions." },
    ],
    importantPeople: [
      { name: "Elena Aprile", contribution: "Founder and PI of the XENON experiment series at Gran Sasso; pioneered dual-phase liquid-xenon technology for dark matter detection." },
      { name: "Gianpaolo Bellini", contribution: "Led the BOREXINO experiment for decades; key architect of the solar neutrino spectroscopy programme that achieved the pp neutrino measurement." },
    ],
    readMore: [
      { label: "LNGS Official Site", url: "https://www.lngs.infn.it" },
      { label: "XENON Experiment", url: "https://xenonexperiment.org" },
    ],
  },

  {
    id: 'snolab',
    name: 'SNOLAB',
    country: 'Canada',
    lat: 46.475,
    lng: -81.201,
    founded: 2004,
    status: 'active',
    overview: "SNOLAB, located 2 km underground in the Creighton nickel mine near Sudbury, Ontario, is the world's deepest clean-room laboratory. Its predecessor, the Sudbury Neutrino Observatory (SNO), resolved the 30-year solar neutrino problem in 2002 by proving that electron neutrinos produced in the Sun oscillate into other flavours. SNOLAB now hosts experiments searching for dark matter (DEAP-3600, NEWS-G) and neutrinoless double-beta decay (SNO+).",
    history: [
      { year: 1999, event: "SNO detector begins operations, using 1,000 tonnes of heavy water to separately detect charged-current and neutral-current neutrino interactions." },
      { year: 2001, event: "SNO charged-current result shows the solar electron-neutrino flux is one-third the Standard Solar Model prediction, hinting strongly at flavour change." },
      { year: 2002, event: "SNO neutral-current measurement proves the total active neutrino flux matches solar model predictions, establishing that solar electron-neutrinos oscillate into other flavours. Nobel Prize 2015." },
      { year: 2012, event: "SNOLAB officially opens as an expanded underground facility, adding new experimental halls adjacent to the original SNO cavity." },
      { year: 2022, event: "SNO+ begins filling its 780-tonne acrylic vessel with tellurium-loaded liquid scintillator for neutrinoless double-beta decay searches." },
    ],
    experiments: [
      { id: 'snolab-snop', name: 'SNO+', description: "Repurposes the SNO heavy-water vessel with liquid scintillator doped with 130-Te to search for neutrinoless double-beta decay and measure reactor antineutrinos.", topics: ['neutrinos'], startYear: 2017 },
      { id: 'snolab-deap', name: 'DEAP-3600', description: "3,600-kg liquid-argon scintillation detector searching for WIMP dark matter at the world's deepest clean-room laboratory using a single-phase technique.", topics: ['dark-matter'], startYear: 2016 },
    ],
    keyResults: [
      { year: 2002, discovery: "Resolution of the Solar Neutrino Problem", description: "SNO's neutral-current measurement proved the total solar neutrino flux matches the Standard Solar Model — solar electron-neutrinos oscillate into other active flavours, confirming neutrino mass. Nobel Prize in Physics 2015." },
    ],
    importantPeople: [
      { name: "Arthur McDonald", contribution: "Director of the SNO collaboration; his team's neutral-current measurement definitively resolved the solar neutrino problem. Nobel Prize in Physics 2015." },
      { name: "Hamish Robertson", contribution: "Co-spokesperson of SNO; expert in neutrino mass measurement and a founding architect of the heavy-water detector concept." },
    ],
    readMore: [
      { label: "SNOLAB Official Site", url: "https://www.snolab.ca" },
      { label: "Nobel Prize 2015 (Neutrino Oscillations)", url: "https://www.nobelprize.org/prizes/physics/2015/summary/" },
    ],
  },

  {
    id: 'kamioka',
    name: 'Kamioka Observatory',
    country: 'Japan',
    lat: 36.4254,
    lng: 137.31,
    founded: 1983,
    status: 'active',
    overview: "Japan's Kamioka Observatory, housed beneath Mount Ikeno in Gifu Prefecture, is one of the most productive underground laboratories in the world. Its flagship detector Super-Kamiokande — a 50,000-tonne water Cherenkov cylinder — detected the first neutrinos from an extragalactic supernova (1987A), discovered atmospheric neutrino oscillations in 1998, and sets world-leading limits on the proton lifetime. The successor Hyper-Kamiokande, a 260,000-tonne detector, is currently under construction nearby.",
    history: [
      { year: 1983, event: "Kamiokande detector begins operations under Mount Ikeno, designed primarily to search for proton decay predicted by Grand Unified Theories." },
      { year: 1987, event: "Kamiokande-II detects 11 neutrinos from Supernova 1987A in the Large Magellanic Cloud — the first detection of neutrinos from any extragalactic source. Nobel Prize 2002." },
      { year: 1996, event: "Super-Kamiokande, a 50,000-tonne water Cherenkov detector instrumented with 11,146 photomultiplier tubes, begins operations." },
      { year: 1998, event: "Super-Kamiokande announces compelling evidence for atmospheric muon-neutrino oscillation, proving neutrinos have non-zero mass. Nobel Prize 2015." },
      { year: 2020, event: "Super-Kamiokande enters its Gd-doping phase (SK-Gd), adding gadolinium to improve neutron-capture detection for supernova relic neutrino searches." },
    ],
    experiments: [
      { id: 'kamioka-sk', name: 'Super-Kamiokande', description: "50,000-tonne water Cherenkov detector that discovered atmospheric neutrino oscillations, setting world-leading proton-lifetime limits and observing solar and atmospheric neutrinos.", topics: ['neutrinos'], startYear: 1996 },
      { id: 'kamioka-kamland', name: 'KamLAND', description: "1-kilotonne liquid-scintillator detector at Kamioka; the first to observe reactor antineutrino disappearance with terrestrial sources, confirming neutrino oscillation parameters.", topics: ['neutrinos'], startYear: 2002 },
    ],
    keyResults: [
      { year: 1987, discovery: "Supernova 1987A Neutrinos", description: "Kamiokande-II detected a burst of 11 neutrinos from SN 1987A, providing the first direct observation of core-collapse supernova neutrinos and confirming stellar collapse models. Masatoshi Koshiba shared the Nobel Prize 2002." },
      { year: 1998, discovery: "Atmospheric Neutrino Oscillations", description: "Super-Kamiokande observed a zenith-angle-dependent deficit of atmospheric muon neutrinos, providing compelling evidence that neutrinos oscillate and therefore have non-zero mass. Nobel Prize 2015." },
    ],
    importantPeople: [
      { name: "Masatoshi Koshiba", contribution: "Led the Kamiokande experiment and directed the 1987A supernova neutrino detection; Nobel Prize in Physics 2002." },
      { name: "Takaaki Kajita", contribution: "Analysed Super-Kamiokande atmospheric neutrino data, discovering the oscillation signature that proved neutrino mass; Nobel Prize in Physics 2015." },
    ],
    readMore: [
      { label: "Super-Kamiokande Site", url: "https://www-sk.icrr.u-tokyo.ac.jp" },
      { label: "Nobel Prize 2002 (SN1987A)", url: "https://www.nobelprize.org/prizes/physics/2002/summary/" },
      { label: "Nobel Prize 2015 (Oscillations)", url: "https://www.nobelprize.org/prizes/physics/2015/summary/" },
    ],
  },

  {
    id: 'surf',
    name: 'SURF / LUX-ZEPLIN',
    country: 'United States',
    lat: 44.352,
    lng: -103.771,
    founded: 2006,
    status: 'active',
    overview: "The Sanford Underground Research Facility (SURF) occupies the former Homestake Gold Mine in Lead, South Dakota, at a depth of 1,478 m. Its predecessor, the Homestake experiment begun in 1965, was the first to detect solar neutrinos and created the solar neutrino problem that drove 30 years of physics. Today SURF houses LUX-ZEPLIN (LZ) — a 10-tonne dual-phase liquid-xenon detector that holds the world record for WIMP dark matter sensitivity.",
    history: [
      { year: 1965, event: "Raymond Davis Jr. begins the chlorine radiochemical solar-neutrino experiment deep in the Homestake Mine, using 615 tonnes of perchloroethylene as target." },
      { year: 1968, event: "Davis reports a deficit of only one-third the predicted solar neutrino flux — the beginning of the solar neutrino problem that took three decades to resolve." },
      { year: 2003, event: "Homestake Mine closes gold operations; conversion to a dedicated underground science facility begins with DOE and NSF support." },
      { year: 2006, event: "Sanford Underground Research Facility (SURF) formally established at the 4,850-ft level of the old Homestake Mine." },
      { year: 2022, event: "LUX-ZEPLIN (LZ) completes its first science run, setting the world's most stringent upper limits on the spin-independent WIMP-nucleon cross section." },
    ],
    experiments: [
      { id: 'surf-lz', name: 'LUX-ZEPLIN (LZ)', description: "10-tonne dual-phase liquid-xenon time-projection chamber — the world's most sensitive direct dark matter detector, searching for WIMP nuclear recoils at the 4,850-ft level.", topics: ['dark-matter'], startYear: 2022 },
      { id: 'surf-majorana', name: 'MAJORANA DEMONSTRATOR', description: "Array of enriched germanium detectors searching for neutrinoless double-beta decay of 76-Ge, probing the Majorana nature of the neutrino.", topics: ['neutrinos'], startYear: 2015, endYear: 2021 },
    ],
    keyResults: [
      { year: 1968, discovery: "Solar Neutrino Deficit (Homestake)", description: "Davis's chlorine experiment measured only ~1/3 of the predicted solar neutrino flux, posing the solar neutrino problem that ultimately proved neutrino oscillation and mass. Nobel Prize in Physics 2002." },
      { year: 2023, discovery: "World-Leading WIMP Dark Matter Limits (LZ)", description: "LZ set the most stringent upper limits on the WIMP-nucleon spin-independent cross section for WIMP masses above ~9 GeV/c2, constraining large regions of supersymmetric dark matter parameter space." }, // [verify: best LZ published result year]
    ],
    importantPeople: [
      { name: "Raymond Davis Jr.", contribution: "Built and operated the Homestake solar neutrino experiment (1965-2002), creating the solar neutrino problem; Nobel Prize in Physics 2002." },
      { name: "Richard Gaitskell", contribution: "Co-spokesperson of LZ and architect of the LUX and LZ liquid-xenon dark matter programme at SURF." },
    ],
    readMore: [
      { label: "SURF Official Site", url: "https://sanfordlab.org" },
      { label: "LZ Experiment", url: "https://lz.lbl.gov" },
      { label: "Nobel Prize 2002 (Solar Neutrinos)", url: "https://www.nobelprize.org/prizes/physics/2002/summary/" },
    ],
  },

  // ─── Neutrino Observatories ───────────────────────────────────────────────

  {
    id: 'icecube',
    name: 'IceCube Neutrino Observatory',
    country: 'Antarctica',
    lat: -89.9944,
    lng: -63.4536,
    founded: 2010,
    status: 'active',
    overview: "The IceCube Neutrino Observatory at the geographic South Pole instruments a cubic kilometre of Antarctic ice between 1.5 and 2.5 km depth with 5,160 Digital Optical Modules on 86 vertical strings. It detects Cherenkov light from secondary particles produced when high-energy neutrinos interact in the ice — the world's largest neutrino telescope. IceCube opened the field of high-energy neutrino astronomy with its 2013 astrophysical neutrino detection, and in 2022 identified NGC 1068 as a cosmic neutrino source.",
    history: [
      { year: 1992, event: "AMANDA (Antarctic Muon And Neutrino Detector Array) begins deployment as a proof-of-concept for deep-ice neutrino detection at the South Pole." },
      { year: 2004, event: "IceCube drilling and DOM deployment begins, expanding on AMANDA infrastructure." },
      { year: 2010, event: "IceCube construction completed with all 86 strings and 5,160 DOMs deployed; the world's largest neutrino telescope begins full operations." },
      { year: 2013, event: "IceCube announces the first detection of high-energy astrophysical neutrinos above 100 TeV, naming two PeV-scale events Bert and Ernie — opening the era of neutrino astronomy." },
      { year: 2022, event: "IceCube publishes evidence at 4.2 sigma for neutrino emission from NGC 1068 (Messier 77), a nearby Seyfert galaxy — the first identified steady-state cosmic neutrino source." },
    ],
    experiments: [
      { id: 'icecube-main', name: 'IceCube', description: "Cubic-kilometre deep-ice neutrino telescope detecting TeV-PeV astrophysical neutrinos from cosmic accelerators including active galactic nuclei, gamma-ray bursts, and galaxy clusters.", topics: ['neutrinos', 'cosmic-rays'], startYear: 2010 },
      { id: 'icecube-deepcore', name: 'DeepCore', description: "Dense low-energy sub-array of IceCube with a ~10 GeV threshold; measures atmospheric neutrino oscillation parameters and searches for dark matter annihilation in the Sun.", topics: ['neutrinos', 'dark-matter'], startYear: 2010 },
    ],
    keyResults: [
      { year: 2013, discovery: "First High-Energy Astrophysical Neutrinos", description: "IceCube detected the first neutrinos of clear extraterrestrial origin at energies above 100 TeV, inaugurating high-energy neutrino astronomy and demonstrating the existence of PeV-scale cosmic accelerators." },
      { year: 2022, discovery: "NGC 1068 Identified as Neutrino Source", description: "Statistical evidence for neutrino emission from the Seyfert galaxy NGC 1068 provided the first identification of a steady-state astrophysical neutrino source, likely powered by accretion onto its central supermassive black hole." },
    ],
    importantPeople: [
      { name: "Francis Halzen", contribution: "Principal investigator and chief scientific architect of IceCube; built the scientific case for deep-ice neutrino detection over three decades." },
      { name: "Albrecht Karle", contribution: "IceCube co-investigator who led key aspects of detector calibration and the astrophysical neutrino analyses." },
    ],
    readMore: [
      { label: "IceCube Official Site", url: "https://icecube.wisc.edu" },
      { label: "2013 Discovery Paper (Science)", url: "https://doi.org/10.1126/science.1242856" },
    ],
  },

  {
    id: 'juno',
    name: 'JUNO',
    country: 'China',
    lat: 22.118,
    lng: 112.518,
    founded: 2015,
    status: 'active', // [verify: JUNO entered commissioning 2024-2025]
    overview: "The Jiangmen Underground Neutrino Observatory (JUNO) in Guangdong Province, China, is the world's largest liquid-scintillator neutrino detector — a 20,000-tonne sphere at 700 m depth instrumented with over 17,000 large photomultiplier tubes. Its primary goals are to determine the neutrino mass ordering (normal vs. inverted hierarchy) and to measure the oscillation parameters sin2-theta-12 and Delta-m2-21 to sub-percent precision, using reactor antineutrinos from nearby nuclear power plants.",
    history: [
      { year: 2012, event: "JUNO proposed at the Institute of High Energy Physics, Beijing, building on the success of the Daya Bay theta-13 measurement." },
      { year: 2015, event: "Construction of the JUNO underground experimental hall begins near Kaiping, Jiangmen, Guangdong." },
      { year: 2021, event: "Installation of the 20-inch and 3-inch photomultiplier tube systems begins; a novel dual-calorimetry design improves energy resolution." },
      { year: 2024, event: "JUNO begins filling its 20,000-tonne acrylic sphere with liquid scintillator; commissioning underway." }, // [verify]
    ],
    experiments: [
      { id: 'juno-main', name: 'JUNO Main Detector', description: "20,000-tonne liquid-scintillator sphere designed to determine the neutrino mass ordering and measure oscillation parameters using reactor antineutrinos from two nearby nuclear power complexes.", topics: ['neutrinos'], startYear: 2024 }, // [verify start year]
    ],
    keyResults: [],
    importantPeople: [
      { name: "Yifang Wang", contribution: "Director of IHEP Beijing and founding proposer of JUNO; also chief scientist of the Daya Bay experiment." },
      { name: "Jun Cao", contribution: "JUNO technical coordinator; previously led analysis in the Daya Bay experiment that first measured theta-13." },
    ],
    readMore: [
      { label: "JUNO Official Site", url: "https://juno.ihep.ac.cn" },
    ],
  },

  {
    id: 'daya-bay',
    name: 'Daya Bay',
    country: 'China',
    lat: 22.5956,
    lng: 114.5378,
    founded: 2011,
    status: 'historic',
    overview: "The Daya Bay Reactor Neutrino Experiment operated from 2011 to 2020 near nuclear power plants in Guangdong, China. Using eight gadolinium-doped liquid-scintillator detectors across three underground halls at baselines of 360-1860 m from the reactors, Daya Bay made the world's most precise measurement of the mixing angle theta-13 — a critical parameter for future experiments seeking to measure the neutrino CP-violating phase delta-CP.",
    history: [
      { year: 2011, event: "Daya Bay begins operations with the first set of antineutrino detectors installed in underground experimental halls." },
      { year: 2012, event: "Daya Bay announces the first precise measurement of theta-13, finding sin2(2*theta-13) = 0.092 at more than 5 sigma — the world's first observation of non-zero theta-13." },
      { year: 2013, event: "Full eight-detector configuration begins operations, significantly improving statistical and systematic precision." },
      { year: 2020, event: "Daya Bay completes data-taking after nine years; final results represent the world's most precise measurement of theta-13." },
    ],
    experiments: [
      { id: 'dayabay-det', name: 'Daya Bay Antineutrino Detectors', description: "Eight modular Gd-doped liquid-scintillator detectors in three underground halls measuring reactor antineutrino disappearance to extract theta-13 with sub-percent precision.", topics: ['neutrinos', 'electroweak'], startYear: 2011, endYear: 2020 },
    ],
    keyResults: [
      { year: 2012, discovery: "First Precise Measurement of theta-13", description: "Daya Bay was the first experiment to measure the neutrino mixing angle theta-13 with >5 sigma significance, finding it unexpectedly large (sin2(2*theta-13) ~ 0.089), enabling the design of experiments to measure the neutrino CP-violating phase delta-CP." },
    ],
    importantPeople: [
      { name: "Yifang Wang", contribution: "Chief scientist of the Daya Bay experiment and director of IHEP Beijing; architect of the multi-detector near/far baseline strategy." },
      { name: "Kam-Biu Luk", contribution: "Co-spokesperson of Daya Bay (UC Berkeley / LBNL); led the US contribution and statistical analysis strategy." },
    ],
    readMore: [
      { label: "Daya Bay at IHEP", url: "http://dayabay.ihep.ac.cn" }, // [verify URL]
    ],
  },

  // ─── Cosmic-Ray / Gamma-Ray ───────────────────────────────────────────────

  {
    id: 'pierre-auger',
    name: 'Pierre Auger Observatory',
    country: 'Argentina',
    lat: -35.208,
    lng: -69.314,
    founded: 2008,
    status: 'active',
    overview: "The Pierre Auger Observatory in Mendoza Province, Argentina, covers 3,000 km2 of the Pampa Amarilla with 1,660 water-Cherenkov surface detectors and 27 fluorescence telescopes — the world's largest cosmic-ray detector. It measures ultra-high-energy cosmic rays (UHECRs) above 10^18 eV, addressing the mystery of the origin, nature, and maximum energy of cosmic rays. The ongoing AugerPrime upgrade adds scintillators and radio antennas for improved composition sensitivity.",
    history: [
      { year: 1992, event: "Pierre Auger Observatory proposed by James Cronin (U. Chicago) and Alan Watson (U. Leeds) to resolve the origin and spectrum of ultra-high-energy cosmic rays." },
      { year: 2004, event: "First surface detectors deployed in the Pampa Amarilla; the hybrid detection technique combining surface stations and fluorescence telescopes is pioneered." },
      { year: 2008, event: "Pierre Auger Observatory declared complete with all 1,600 surface detectors and 24 fluorescence telescopes operational." },
      { year: 2017, event: "Auger reports evidence for a large-scale anisotropy in cosmic-ray arrival directions above 8 EeV at 5.2 sigma, indicating an extragalactic origin." },
      { year: 2022, event: "AugerPrime upgrade begins, adding scintillator detectors and radio antennas above all 1,660 surface stations to measure shower composition." },
    ],
    experiments: [
      { id: 'auger-sd', name: 'Surface Detector (SD)', description: "Array of 1,660 water-Cherenkov tanks across 3,000 km2 measuring muon and electromagnetic shower particles from UHECR air showers with 100% duty cycle.", topics: ['cosmic-rays'], startYear: 2004 },
      { id: 'auger-fd', name: 'Fluorescence Detector (FD)', description: "27 Schmidt telescopes measuring nitrogen fluorescence from extensive air showers to calibrate the SD energy scale and determine shower maximum Xmax for composition analysis.", topics: ['cosmic-rays'], startYear: 2004 },
    ],
    keyResults: [
      { year: 2007, discovery: "Correlation of UHECRs with Active Galactic Nuclei", description: "Auger reported a correlation between arrival directions of UHECRs above 60 EeV and the positions of nearby AGN in the Veron-Cetty catalogue, suggesting extragalactic origin from powerful astrophysical accelerators." },
      { year: 2017, discovery: "Large-Scale Anisotropy in UHECR Arrival Directions", description: "A 5.2 sigma large-scale anisotropy above 8 EeV points towards the direction of the Virgo supercluster, providing the first statistically significant directional signal indicating the extragalactic origin of UHECRs." },
    ],
    importantPeople: [
      { name: "James Cronin", contribution: "Co-proposed the Pierre Auger Observatory; Nobel Prize in Physics 1980 for CP violation in kaon decays, which shaped his interest in fundamental cosmic phenomena." },
      { name: "Alan Watson", contribution: "Co-proposed and co-led construction of the Auger Observatory; pioneer of UHECR detection using the Haverah Park array." },
    ],
    readMore: [
      { label: "Pierre Auger Observatory", url: "https://www.auger.org" },
      { label: "Nobel Prize 1980 (Cronin)", url: "https://www.nobelprize.org/prizes/physics/1980/summary/" },
    ],
  },

  {
    id: 'cta',
    name: 'CTAO / CTA',
    country: 'Spain / Chile',
    lat: 28.762,
    lng: -17.892,
    founded: 2019,
    status: 'planned',
    overview: "The Cherenkov Telescope Array Observatory (CTAO) will be the world's largest and most sensitive ground-based gamma-ray observatory, with two sites: CTA-North at La Palma, Canary Islands, and CTA-South near ESO's Paranal Observatory in Chile. The full array of ~70 imaging atmospheric Cherenkov telescopes in three size classes will cover 20 GeV to 300 TeV with order-of-magnitude improvements in sensitivity over current instruments, enabling studies of dark matter annihilation, cosmic-ray origin, AGN jets, and pulsar wind nebulae.",
    history: [
      { year: 2010, event: "CTA concept formally developed by an international consortium; the multi-telescope multi-size-class architecture is defined." },
      { year: 2019, event: "CTAO ERIC (European Research Infrastructure Consortium) legal entity established, headquartered in Bologna, Italy." },
      { year: 2021, event: "LST-1 prototype Large-Sized Telescope at La Palma begins regular observations as a CTA precursor instrument." },
      { year: 2023, event: "Production of CTA-North array telescopes (LST-2 through LST-4) underway; CTA-South site preparation ongoing at Paranal." }, // [verify]
    ],
    experiments: [
      { id: 'cta-north', name: 'CTA-North (La Palma)', description: "Northern array at La Palma optimised for lower-energy gamma-rays (20 GeV-1 TeV); targets AGN jets, dark matter, and transient sources including gamma-ray bursts.", topics: ['cosmic-rays', 'dark-matter'] },
      { id: 'cta-south', name: 'CTA-South (Paranal)', description: "Southern array at Paranal optimised for higher-energy gamma-rays (100 GeV-300 TeV); surveys the full Southern sky including the Galactic Centre and supernova remnants.", topics: ['cosmic-rays', 'dark-matter'] },
    ],
    keyResults: [],
    importantPeople: [
      { name: "Werner Hofmann", contribution: "Former spokesperson of H.E.S.S. and a key scientific architect of the CTA telescope array concept and science case." },
      { name: "Jim Hinton", contribution: "CTAO science lead and expert in very-high-energy gamma-ray astrophysics and the origin of Galactic cosmic rays." },
    ],
    readMore: [
      { label: "CTAO Official Site", url: "https://www.ctao.org" },
    ],
  },

  // ─── Gravitational Wave ───────────────────────────────────────────────────

  {
    id: 'ligo',
    name: 'LIGO',
    country: 'United States',
    lat: 46.455,
    lng: -119.408,
    founded: 2002,
    status: 'active',
    overview: "The Laser Interferometer Gravitational-wave Observatory (LIGO) consists of two identical 4-km L-shaped interferometers — one near Hanford, Washington, and one in Livingston, Louisiana — operated by Caltech and MIT. On 14 September 2015, Advanced LIGO made the first direct detection of gravitational waves from a binary black hole merger (GW150914), opening the era of gravitational-wave astronomy. The Nobel Prize in Physics 2017 was awarded to LIGO founders Rainer Weiss, Kip Thorne, and Barry Barish.",
    history: [
      { year: 1992, event: "LIGO project approved by the US National Science Foundation; Kip Thorne, Rainer Weiss, and Rochus Vogt lead the design." },
      { year: 2002, event: "LIGO begins its first science run (S1), initiating decades of progressively sensitive observation campaigns." },
      { year: 2015, event: "Advanced LIGO begins O1; on 14 September 2015, GW150914 — a binary black hole merger — is detected, the first direct observation of gravitational waves in history." },
      { year: 2017, event: "LIGO and Virgo jointly detect GW170817, the first binary neutron star merger, observed simultaneously across the electromagnetic spectrum from gamma rays to radio." },
      { year: 2023, event: "LIGO's fourth observing run (O4) begins with A+ sensitivity improvements; binary mergers are detected routinely, at a rate of several per week." },
    ],
    experiments: [
      { id: 'ligo-aligo', name: 'Advanced LIGO (aLIGO)', description: "Two 4-km Fabry-Perot Michelson interferometers with 400-kW circulating laser power; sensitive to gravitational-wave strains around 10-23 per root Hz near 100 Hz.", topics: ['gravitational-waves'], startYear: 2015 },
    ],
    keyResults: [
      { year: 2015, discovery: "First Detection of Gravitational Waves (GW150914)", description: "LIGO detected gravitational waves from the merger of two black holes (~30 and ~35 solar masses each), confirming a central prediction of general relativity 100 years after Einstein made it. Nobel Prize in Physics 2017." },
      { year: 2017, discovery: "Binary Neutron Star Merger GW170817", description: "LIGO and Virgo observed the merger of two neutron stars along with a short gamma-ray burst and kilonova — the first multi-messenger gravitational-wave event, confirming neutron star mergers as sites of r-process nucleosynthesis and heavy element production." },
    ],
    importantPeople: [
      { name: "Rainer Weiss", contribution: "Co-founded LIGO and invented the laser interferometer technique for gravitational-wave detection; Nobel Prize in Physics 2017." },
      { name: "Kip Thorne", contribution: "Co-founded LIGO and developed the theoretical predictions for binary merger waveforms that enabled GW150914's identification; Nobel Prize in Physics 2017." },
      { name: "Barry Barish", contribution: "Director of the LIGO Laboratory (1994-2005) who transformed the project into the instrument that detected gravitational waves; Nobel Prize in Physics 2017." },
    ],
    readMore: [
      { label: "LIGO Official Site", url: "https://www.ligo.caltech.edu" },
      { label: "Nobel Prize 2017 (Gravitational Waves)", url: "https://www.nobelprize.org/prizes/physics/2017/summary/" },
      { label: "GW Open Science Center", url: "https://gwosc.org" },
    ],
  },

  {
    id: 'virgo',
    name: 'Virgo',
    country: 'Italy',
    lat: 43.631,
    lng: 10.504,
    founded: 2007,
    status: 'active',
    overview: "The Virgo gravitational-wave detector is a 3-km L-shaped laser interferometer near Cascina, Pisa, operated by the European Gravitational Observatory (EGO) consortium. Joining the LIGO network in 2017, the addition of a third detector improved source sky localisation from ~1,000 deg2 to tens of deg2, enabling rapid electromagnetic follow-up of mergers. Advanced Virgo+ operates with frequency-dependent squeezing and improved mirror coatings.",
    history: [
      { year: 1989, event: "Virgo proposed by Adalberto Giazotto (INFN Pisa) and Alain Brillet (LAL Orsay); site selected at Cascina in the Arno valley." },
      { year: 2003, event: "Virgo detector construction completed; commissioning and first science runs begin." },
      { year: 2007, event: "Virgo joins LIGO for joint science run VSR1/S5, establishing the LIGO-Virgo collaboration." },
      { year: 2017, event: "Advanced Virgo joins LIGO O2; GW170814 is the first three-detector gravitational-wave observation, dramatically improving sky localisation. GW170817 follows days later." },
      { year: 2023, event: "Advanced Virgo+ begins O4 with frequency-dependent quantum squeezing, targeting design sensitivity." },
    ],
    experiments: [
      { id: 'virgo-adv', name: 'Advanced Virgo+', description: "3-km Fabry-Perot Michelson interferometer with power recycling, signal recycling, and frequency-dependent squeezing; jointly detects and localises gravitational-wave sources with LIGO.", topics: ['gravitational-waves'], startYear: 2017 },
    ],
    keyResults: [
      { year: 2017, discovery: "First Three-Detector Gravitational-Wave Observation (GW170814)", description: "LIGO Hanford, LIGO Livingston, and Virgo together detected a binary black hole merger, reducing the 90% credible sky area from ~1,000 deg2 to ~60 deg2 — enabling rapid multi-messenger follow-up of compact binary mergers." },
    ],
    importantPeople: [
      { name: "Adalberto Giazotto", contribution: "Co-founded the Virgo experiment; invented the superattenuation seismic isolation system that gives Virgo world-leading sensitivity at low frequencies." },
      { name: "Alain Brillet", contribution: "Co-proposed Virgo and led French contributions; expert in laser stabilisation and optical techniques for interferometric detection." },
    ],
    readMore: [
      { label: "EGO / Virgo", url: "https://www.ego-gw.it" },
      { label: "Virgo Collaboration", url: "https://www.virgo-gw.eu" },
    ],
  },

  {
    id: 'kagra',
    name: 'KAGRA',
    country: 'Japan',
    lat: 36.411,
    lng: 137.306,
    founded: 2019,
    status: 'active',
    overview: "KAGRA (Kamioka Gravitational Wave Detector) is the first large-scale gravitational-wave detector built underground and using cryogenic sapphire mirrors cooled to 20 K. Located in the Kamioka mine in Gifu Prefecture, its 3-km interferometer is designed to reduce seismic and thermal noise below the limits of current LIGO/Virgo sensitivity. KAGRA joined the LIGO-Virgo network for O3b in 2020 and O4 in 2023, bringing the global network to three continents.",
    history: [
      { year: 2010, event: "KAGRA (originally LCGT, Large-scale Cryogenic Gravitational wave Telescope) approved by the Japanese government and MEXT." },
      { year: 2012, event: "Tunnel excavation begins inside the Kamioka mine, sharing the mountain with the Super-Kamiokande detector." },
      { year: 2019, event: "KAGRA achieves first lock and declares operational status; first observation run (O3b) begins." },
      { year: 2020, event: "KAGRA briefly joins the LIGO-Virgo O3b run, marking the first time gravitational-wave detectors on three continents operated simultaneously." },
      { year: 2023, event: "KAGRA participates in O4 with progressively improving sensitivity; cryogenic operation ongoing towards design goal." },
    ],
    experiments: [
      { id: 'kagra-det', name: 'KAGRA Interferometer', description: "3-km cryogenic underground Fabry-Perot Michelson interferometer using sapphire test masses at 20 K, targeting improved sensitivity below 100 Hz compared to room-temperature detectors.", topics: ['gravitational-waves'], startYear: 2019 },
    ],
    keyResults: [],
    importantPeople: [
      { name: "Takaaki Kajita", contribution: "Principal investigator of KAGRA; also Nobel Prize in Physics 2015 for the discovery of atmospheric neutrino oscillations at Super-Kamiokande." },
      { name: "Kazuoki Kuroda", contribution: "Founding proposer of LCGT/KAGRA and pioneer of cryogenic mirror technology for gravitational-wave detection." }, // [verify]
    ],
    readMore: [
      { label: "KAGRA Official Site", url: "https://gwcenter.icrr.u-tokyo.ac.jp" },
    ],
  },

  // ─── Nuclear / Rare Isotope ───────────────────────────────────────────────

  {
    id: 'frib',
    name: 'FRIB',
    country: 'United States',
    lat: 42.727,
    lng: -84.484,
    founded: 2022,
    status: 'active',
    overview: "The Facility for Rare Isotope Beams (FRIB) at Michigan State University, which opened to users in May 2022, is the world's most powerful rare-isotope accelerator. A superconducting linear accelerator drives uranium and other heavy-ion beams to roughly half the speed of light and fragments them on beryllium targets to produce thousands of exotic radioactive isotopes — including those that exist only in neutron stars and supernovae. FRIB enables tests of nuclear force models near the neutron drip line and measurements critical to understanding r-process nucleosynthesis.",
    history: [
      { year: 2008, event: "DOE approves FRIB as a major scientific user facility at Michigan State University, successor to the National Superconducting Cyclotron Laboratory (NSCL)." },
      { year: 2014, event: "FRIB construction begins; the superconducting linac tunnel is excavated on the MSU campus in East Lansing." },
      { year: 2022, event: "FRIB opens to user experiments on 2 May 2022; first uranium beams reach over 200 MeV/u, setting a world record for beam power with that ion." },
      { year: 2023, event: "FRIB user experiments publish first measurements of exotic nuclei near the neutron drip line, extending the nuclear chart to new territories." },
    ],
    experiments: [
      { id: 'frib-greta', name: 'GRETA', description: "Gamma-Ray Energy Tracking Array — a 4-pi germanium detector that tracks gamma-ray photons from nuclear reactions, enabling in-beam spectroscopy of rare isotopes at FRIB.", topics: ['nuclear-structure', 'rare-isotopes'], startYear: 2023 }, // [verify GRETA commissioning date]
      { id: 'frib-mona', name: 'MoNA-LISA', description: "Modular Neutron Array and Large-area multi-Institutional Scintillator Array; measures neutrons from rare isotope decays near the drip line to probe nuclear structure and halo nuclei.", topics: ['nuclear-structure', 'rare-isotopes'], startYear: 2022 },
    ],
    keyResults: [
      { year: 2022, discovery: "New Isotopes on First Day of Operations", description: "Within days of opening, FRIB produced and identified previously unobserved neutron-rich isotopes, demonstrating its power to extend the nuclear chart." },
      { year: 2023, discovery: "Neutron Drip-Line Measurements in Neutron-Rich Nuclei", description: "FRIB experiments measured binding energies and decay properties of highly neutron-rich isotopes, probing the edges of nuclear stability and testing ab initio nuclear structure calculations." }, // [verify specifics]
    ],
    importantPeople: [
      { name: "Konrad Gelbke", contribution: "First director of FRIB and its predecessor NSCL; led the multi-decade effort to secure approval and funding for FRIB at Michigan State." },
      { name: "Brad Sherrill", contribution: "FRIB scientific director; expert in rare-isotope beam production and nuclear astrophysics measurements." },
    ],
    readMore: [
      { label: "FRIB Official Site", url: "https://frib.msu.edu" },
    ],
  },

  {
    id: 'gsi',
    name: 'GSI / FAIR',
    country: 'Germany',
    lat: 49.934,
    lng: 8.672,
    founded: 1969,
    status: 'active',
    overview: "The GSI Helmholtz Centre for Heavy Ion Research in Darmstadt operates a heavy-ion accelerator complex and is home to FAIR (Facility for Antiproton and Ion Research), currently under construction on the same campus. GSI is internationally renowned for synthesising six new super-heavy elements (Bohrium to Copernicium, Z=107-112) between 1981 and 1996, for pioneering heavy-ion cancer therapy in the 1990s, and for its HADES spectrometer studying dense hadronic matter. FAIR will collide heavy ions and antiprotons at unprecedented intensities.",
    history: [
      { year: 1969, event: "GSI founded as Germany's national heavy-ion research centre; the UNILAC linear accelerator begins operations." },
      { year: 1981, event: "Peter Armbruster and Gottfried Munzenberg's team synthesises element 107 (Bohrium) using the velocity filter SHIP, beginning two decades of super-heavy element discovery." },
      { year: 1994, event: "GSI synthesises elements 110 (Darmstadtium) and 111 (Roentgenium), approaching the predicted island of stability for super-heavy nuclei." },
      { year: 1997, event: "First cancer patients treated with heavy-ion carbon beams at GSI, pioneering therapy with superior tumour conformality over conventional radiotherapy." },
      { year: 2017, event: "FAIR construction begins on the GSI campus; the new SIS100 synchrotron will deliver ion beams 100 times more intense than current GSI accelerators." },
    ],
    experiments: [
      { id: 'gsi-hades', name: 'HADES', description: "High Acceptance Di-Electron Spectrometer at GSI; studies dense hadronic matter and strangeness production in heavy-ion collisions, relevant to neutron star interior physics.", topics: ['heavy-ions', 'qcd'], startYear: 1997 },
      { id: 'fair-cbm', name: 'CBM (FAIR)', description: "Compressed Baryonic Matter experiment at FAIR; will study the QCD phase diagram at the highest net baryon densities achievable in a laboratory, mapping the nuclear matter phase transition.", topics: ['heavy-ions', 'qcd', 'nuclear-structure'] },
      { id: 'fair-panda', name: 'PANDA (FAIR)', description: "Proton-ANtiproton annihilations at DArmstadt; uses stored antiproton beams to study charmonium spectroscopy, gluonic excitations (hybrids and glueballs), and hypernuclei.", topics: ['qcd', 'nuclear-structure'] },
    ],
    keyResults: [
      { year: 1984, discovery: "Super-Heavy Element 108 (Hassium)", description: "GSI synthesised element 108, Hassium (Hs), at the time the heaviest known element, confirming that the periodic table extends well beyond uranium and approaching the predicted island of stability." },
      { year: 1996, discovery: "Element 112 (Copernicium)", description: "Armbruster and Munzenberg's team synthesised element 112 (later named Copernicium, Cn) via cold-fusion reactions, completing a two-decade programme of super-heavy element discovery at GSI." },
    ],
    importantPeople: [
      { name: "Peter Armbruster", contribution: "Led the GSI super-heavy element synthesis programme; co-discovered six elements from Bohrium (107) to Copernicium (112) between 1981 and 1996." },
      { name: "Gottfried Munzenberg", contribution: "Co-discovered the super-heavy elements at GSI and pioneered the velocity-filter SHIP technology that made single-atom synthesis searches possible." },
    ],
    readMore: [
      { label: "GSI Official Site", url: "https://www.gsi.de" },
      { label: "FAIR Project", url: "https://www.fair-center.eu" },
    ],
  },

  {
    id: 'triumf',
    name: 'TRIUMF',
    country: 'Canada',
    lat: 49.2488,
    lng: -123.2381,
    founded: 1968,
    status: 'active',
    overview: "TRIUMF at the University of British Columbia in Vancouver is Canada's particle accelerator centre. Its 520-MeV H-minus cyclotron — one of the world's largest — drives the ISAC radioactive ion beam facility, producing rare isotopes for nuclear physics, nuclear astrophysics, and medical isotope production. TRIUMF is a world leader in precision mass measurements of short-lived nuclei, gamma-ray spectroscopy of neutron-rich isotopes, and isotopes for cancer therapy. The ARIEL electron linac, commissioned in 2022, triples rare-isotope production capacity.",
    history: [
      { year: 1968, event: "TRIUMF founded by UBC, Simon Fraser University, and the University of Victoria, with construction of a sector-focused cyclotron." },
      { year: 1974, event: "TRIUMF 500 MeV cyclotron begins operations, delivering high-intensity proton beams for meson physics and nuclear science." },
      { year: 1995, event: "ISAC radioactive ion beam facility opens, extending TRIUMF's reach into nuclear astrophysics and precision Standard Model tests." },
      { year: 2010, event: "ISAC-II superconducting linear accelerator begins operations, post-accelerating radioactive beams to Coulomb-barrier energies for nuclear reaction measurements." },
      { year: 2022, event: "ARIEL (Advanced Rare IsotopE Laboratory) electron linac produces first rare isotope beams via photofission, adding a second rare-isotope production route alongside the cyclotron." },
    ],
    experiments: [
      { id: 'triumf-titan', name: 'TITAN', description: "TRIUMF's Ion Trap for Atomic and Nuclear science; precision Penning and Ebit trap system measuring atomic masses of short-lived exotic nuclei with sub-parts-per-billion accuracy.", topics: ['rare-isotopes', 'nuclear-structure'], startYear: 2003 },
      { id: 'triumf-griffin', name: 'GRIFFIN', description: "Gamma-Ray Infrastructure For Fundamental Investigations of Nuclei; 16-detector HPGe array at ISAC for decay spectroscopy of neutron-rich rare isotopes, mapping nuclear structure across the chart of nuclides.", topics: ['nuclear-structure', 'rare-isotopes'], startYear: 2014 },
    ],
    keyResults: [
      { year: 2013, discovery: "Precision Mass Measurements of Light Exotic Nuclei", description: "TITAN's Penning trap measured masses of neutron-rich helium and lithium isotopes with parts-per-billion precision, enabling stringent tests of ab initio nuclear theory and charge-radius calculations." }, // [verify year/details]
      { year: 2019, discovery: "Shell Structure Evolution in Neutron-Rich Isotopes", description: "GRIFFIN spectroscopy at TRIUMF observed unexpected collectivity and shell-structure evolution in neutron-rich nuclei below the Z=28 shell closure, challenging established nuclear shell-model predictions." }, // [verify]
    ],
    importantPeople: [
      { name: "Erich Vogt", contribution: "Founding scientific director of TRIUMF; his advocacy and vision established Canada's national accelerator centre." }, // [verify role]
      { name: "Jens Dilling", contribution: "Head of TRIUMF's nuclear physics programme and PI of the TITAN precision mass measurement project." },
    ],
    readMore: [
      { label: "TRIUMF Official Site", url: "https://www.triumf.ca" },
    ],
  },

  // ─── Synchrotron / Light Source ──────────────────────────────────────────

  {
    id: 'desy',
    name: 'DESY',
    country: 'Germany',
    lat: 53.5741,
    lng: 9.8826,
    founded: 1959,
    status: 'active',
    overview: "Deutsches Elektronen-Synchrotron (DESY) in Hamburg is one of the world's leading accelerator centres. Its PETRA collider hosted the 1979 discovery of the gluon — the carrier of the strong force — in three-jet events. HERA (1992-2007) was the world's only electron-proton collider, mapping proton structure in unprecedented detail. Today DESY operates PETRA III (the world's brightest medium-energy synchrotron source), FLASH (a free-electron laser), and hosts the European XFEL — the world's most powerful X-ray free-electron laser.",
    history: [
      { year: 1959, event: "DESY founded as West Germany's national electron accelerator centre; construction of the 7.5 GeV electron synchrotron begins in Hamburg-Bahrenfeld." },
      { year: 1979, event: "Four experiments (JADE, MARK-J, PLUTO, TASSO) at the PETRA collider simultaneously observe three-jet events in e+e- annihilation — the first direct evidence for the gluon." },
      { year: 1992, event: "HERA, the world's only electron-proton collider (27.5 GeV electrons on 820-920 GeV protons), begins operations with H1 and ZEUS detectors." },
      { year: 2007, event: "HERA completes nine years of e-p physics; PETRA is converted to PETRA III, the world's most brilliant storage-ring X-ray source at its energy." },
      { year: 2017, event: "European XFEL, the world's most powerful X-ray free-electron laser producing up to 27,000 ultra-bright pulses per second, opens at the DESY campus." },
    ],
    experiments: [
      { id: 'desy-tasso', name: 'TASSO at PETRA', description: "Two-Arm Spectrometer Solenoid; one of four PETRA experiments that observed the first three-jet gluon events in e+e- annihilation in 1979, providing direct evidence for QCD.", topics: ['qcd'], startYear: 1979, endYear: 1986 },
      { id: 'desy-h1', name: 'H1 at HERA', description: "General-purpose ep detector measuring deep inelastic scattering to probe quark and gluon distributions inside the proton at Bjorken-x values down to 10-5.", topics: ['qcd'], startYear: 1992, endYear: 2007 },
      { id: 'desy-petra3', name: 'PETRA III', description: "World-class synchrotron radiation source operating at 6 GeV with 20 beamline stations; enables sub-nanometre imaging of materials, proteins, and nanostructures for life and materials science.", topics: ['synchrotron-light'], startYear: 2009 },
    ],
    keyResults: [
      { year: 1979, discovery: "Discovery of the Gluon", description: "Three-jet events in e+e- annihilation at PETRA provided the first direct experimental evidence for the gluon as the mediator of the strong nuclear force — a cornerstone confirmation of QCD." },
      { year: 1994, discovery: "Rise of the Proton Structure Function at Low-x", description: "H1 and ZEUS at HERA observed an unexpected steep rise in the proton gluon density at small Bjorken-x, revealing a new regime of QCD dynamics and motivating the study of gluon saturation." },
    ],
    importantPeople: [
      { name: "Bjorn Wiik", contribution: "DESY director (1993-1999) and HERA project leader; a driving force behind Hamburg's position as a world centre for accelerator-based physics." },
      { name: "Gunter Wolf", contribution: "Led the TASSO experiment at PETRA and made key contributions to the three-jet analysis that established the gluon discovery." }, // [verify]
    ],
    readMore: [
      { label: "DESY Official Site", url: "https://www.desy.de" },
      { label: "European XFEL", url: "https://www.xfel.eu" },
    ],
  },

];
