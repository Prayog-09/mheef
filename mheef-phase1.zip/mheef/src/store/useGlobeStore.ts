import { create } from 'zustand';

interface GlobeState {
  /** Facility currently focused by camera fly-to. Phase 3 will also use
   *  this to decide which facility's data the side panel renders. */
  selectedFacilityId: string | null;
  setSelectedFacilityId: (id: string | null) => void;

  /** Wired up to the (currently inert) TopBar search input now so the
   *  input has somewhere to write to. Phase 4 adds the Fuse.js matching
   *  logic that actually reads this value. */
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // TODO (Phase 4): activeFilters: { topics: string[]; status: string[] }
}

export const useGlobeStore = create<GlobeState>((set) => ({
  selectedFacilityId: null,
  setSelectedFacilityId: (id) => set({ selectedFacilityId: id }),

  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
}));
