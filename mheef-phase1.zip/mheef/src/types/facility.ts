/**
 * FacilityStub is a deliberately minimal placeholder.
 *
 * Phase 2 replaces this with the full `Facility` interface (history,
 * experiments, key results, important people, read-more links, etc.) plus
 * the related `Experiment`, `KeyResult`, `Scientist`, `PhysicsTopic`, and
 * `DetectorTechnology` types described in the master brief. Keeping the
 * shape narrow now means Phase 2 can widen it without touching how
 * Globe.tsx or Marker.tsx consume it positionally (id/lat/lng stay stable).
 */
export interface FacilityStub {
  id: string;
  name: string;
  country: string;
  lat: number;
  lng: number;
}
