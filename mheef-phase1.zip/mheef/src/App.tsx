import TopBar from './components/TopBar';
import Globe from './components/Globe';

export default function App() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-space-950">
      <Globe />
      <TopBar />
    </div>
  );
}
