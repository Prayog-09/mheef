import { Suspense, useEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';
import Earth, { EARTH_RADIUS } from './Earth';
import Atmosphere from './Atmosphere';
import Marker from './Marker';
import { useGlobeStore } from '../store/useGlobeStore';
import type { FacilityStub } from '../types/facility';
import { latLngToVector3 } from '../utils/geo';

/**
 * Phase 1 hardcoded sample set, per the phase brief. Phase 2 deletes this
 * and replaces it with a `.map()` over the full typed dataset imported
 * from /src/data/facilities.ts.
 */
const SAMPLE_FACILITIES: FacilityStub[] = [
  { id: 'cern', name: 'CERN', country: 'Switzerland / France', lat: 46.2331, lng: 6.0558 },
  { id: 'fermilab', name: 'Fermilab', country: 'United States', lat: 41.8316, lng: -88.2456 },
  { id: 'kamioka', name: 'Kamioka Observatory', country: 'Japan', lat: 36.4254, lng: 137.31 },
  { id: 'icecube', name: 'IceCube', country: 'Antarctica', lat: -89.9944, lng: -63.4536 },
  { id: 'slac', name: 'SLAC', country: 'United States', lat: 37.4192, lng: -122.2009 },
  { id: 'gransasso', name: 'Gran Sasso', country: 'Italy', lat: 42.4536, lng: 13.576 },
];

/**
 * Owns OrbitControls and animates the camera toward a selected facility.
 * Reads `selectedFacilityId` from the Zustand store rather than props, so
 * Phase 3 can trigger the same fly-to from the side panel or search
 * results without this component changing.
 */
function CameraRig() {
  const { camera } = useThree();
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const selectedFacilityId = useGlobeStore((s) => s.selectedFacilityId);
  const flightRef = useRef<{ targetPos: THREE.Vector3; targetLook: THREE.Vector3 } | null>(null);

  useEffect(() => {
    if (!selectedFacilityId) return;
    const facility = SAMPLE_FACILITIES.find((f) => f.id === selectedFacilityId);
    if (!facility) return;

    const surfacePos = latLngToVector3(facility.lat, facility.lng, EARTH_RADIUS);
    flightRef.current = {
      targetPos: surfacePos.clone().multiplyScalar(1.9),
      targetLook: surfacePos,
    };

    if (controlsRef.current) {
      controlsRef.current.autoRotate = false;
    }
  }, [selectedFacilityId]);

  useFrame(() => {
    const controls = controlsRef.current;
    const flight = flightRef.current;
    if (!flight || !controls) return;

    camera.position.lerp(flight.targetPos, 0.06);
    controls.target.lerp(flight.targetLook, 0.06);
    controls.update();

    if (camera.position.distanceTo(flight.targetPos) < 0.01) {
      flightRef.current = null;
      controls.autoRotate = true;
    }
  });

  return (
    <OrbitControls
      ref={controlsRef}
      enableDamping
      dampingFactor={0.08}
      autoRotate
      autoRotateSpeed={0.4}
      minDistance={2.6}
      maxDistance={9}
      rotateSpeed={0.5}
      zoomSpeed={0.6}
    />
  );
}

export default function Globe() {
  const setSelectedFacilityId = useGlobeStore((s) => s.setSelectedFacilityId);

  const markers = useMemo(
    () =>
      SAMPLE_FACILITIES.map((facility) => ({
        facility,
        // Lifted slightly above the surface radius to avoid z-fighting
        // with the Earth mesh.
        position: latLngToVector3(facility.lat, facility.lng, EARTH_RADIUS * 1.002),
      })),
    []
  );

  const handleSelect = (facility: FacilityStub) => {
    // Phase 3 replaces this console.log with opening the side panel.
    console.log(`[MHEEF] Selected facility: ${facility.name}`);
    setSelectedFacilityId(facility.id);
  };

  return (
    <div className="absolute inset-0">
      <Canvas camera={{ position: [0, 0, 5.5], fov: 45 }}>
        <color attach="background" args={['#03050a']} />
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 3, 5]} intensity={1.4} />

        <Suspense fallback={null}>
          <Earth />
          <Atmosphere />
        </Suspense>

        <Stars radius={80} depth={40} count={4000} factor={2} saturation={0} fade speed={0.4} />

        {markers.map(({ facility, position }) => (
          <Marker key={facility.id} facility={facility} position={position} onSelect={handleSelect} />
        ))}

        <CameraRig />
      </Canvas>
    </div>
  );
}
