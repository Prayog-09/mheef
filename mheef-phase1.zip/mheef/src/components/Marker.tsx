import { useMemo, useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import type { FacilityStub } from '../types/facility';

interface MarkerProps {
  facility: FacilityStub;
  position: THREE.Vector3;
  onSelect: (facility: FacilityStub) => void;
}

const ACCENT_COLOR = '#22d3ee';

export default function Marker({ facility, position, onSelect }: MarkerProps) {
  const haloRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  // Orients the marker group so its local "up" axis points straight out
  // along the sphere's radius at this point — an extension point for a
  // future pin/cone geometry that needs to stand up off the surface.
  const outwardOrientation = useMemo(() => {
    const up = new THREE.Vector3(0, 1, 0);
    const outward = position.clone().normalize();
    return new THREE.Quaternion().setFromUnitVectors(up, outward);
  }, [position]);

  useFrame((state) => {
    if (!haloRef.current) return;
    const idlePulse = 1 + Math.sin(state.clock.elapsedTime * 2.5) * 0.25;
    haloRef.current.scale.setScalar(hovered ? 1.6 : idlePulse);
  });

  return (
    <group position={position} quaternion={outwardOrientation}>
      <mesh
        onClick={(event) => {
          event.stopPropagation();
          onSelect(facility);
        }}
        onPointerOver={(event) => {
          event.stopPropagation();
          setHovered(true);
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={() => {
          setHovered(false);
          document.body.style.cursor = 'auto';
        }}
      >
        <sphereGeometry args={[0.012, 16, 16]} />
        <meshBasicMaterial color={ACCENT_COLOR} />
      </mesh>

      <mesh ref={haloRef}>
        <sphereGeometry args={[0.02, 16, 16]} />
        <meshBasicMaterial color={ACCENT_COLOR} transparent opacity={0.35} depthWrite={false} />
      </mesh>

      {hovered && (
        <Html distanceFactor={8} center style={{ pointerEvents: 'none' }}>
          <div className="flex flex-col items-center whitespace-nowrap rounded-md border border-accent-400/30 bg-black/70 px-3 py-1.5 text-center backdrop-blur-sm">
            <span className="text-xs font-semibold uppercase tracking-wide text-white">
              {facility.name}
            </span>
            <span className="text-[10px] text-accent-300/70">{facility.country}</span>
          </div>
        </Html>
      )}
    </group>
  );
}
