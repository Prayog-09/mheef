import { Search } from 'lucide-react';
import { useGlobeStore } from '../store/useGlobeStore';

export default function TopBar() {
  const searchQuery = useGlobeStore((s) => s.searchQuery);
  const setSearchQuery = useGlobeStore((s) => s.setSearchQuery);

  return (
    <header className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-center justify-between px-6 py-5">
      <h1 className="pointer-events-auto select-none text-sm font-semibold uppercase tracking-[0.28em] text-white/90">
        MHEEF
      </h1>

      <div className="pointer-events-auto relative w-72">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-accent-300/60" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search facilities..."
          // Phase 4 wires this up to Fuse.js matching + a results dropdown.
          // For now it only writes to the store; nothing reads it yet.
          className="w-full rounded-full border border-accent-400/20 bg-black/40 py-2 pl-9 pr-4 text-sm text-white/80 placeholder:text-white/30 backdrop-blur-md transition-colors focus:border-accent-400/50 focus:outline-none focus:ring-1 focus:ring-accent-400/40"
        />
      </div>
    </header>
  );
}
